"""Model service wrappers with lifecycle management."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Generic, Optional, Protocol, TypeVar
import gc
import logging

import torch


class ModelService(Protocol):
    """Common lifecycle contract for model-backed services."""

    def start(self) -> None:
        """Initialize underlying model resource."""

    def stop(self) -> None:
        """Release underlying model resource."""

    def health(self) -> bool:
        """Return True when service has active model instance."""

    def move_to_device(self, device: str) -> None:
        """Move active model instance to another device."""


class ASRService(ModelService, Protocol):
    """Service contract for ASR model operations."""

    def transcribe(self, *args: Any, **kwargs: Any):
        ...

    def transcribe_from_features(self, *args: Any, **kwargs: Any):
        ...


class TextEmbeddingService(ModelService, Protocol):
    """Service contract for text embedding operations."""

    def encode(self, *args: Any, **kwargs: Any):
        ...


class AudioEmbeddingService(ModelService, Protocol):
    """Service contract for audio embedding operations."""

    def encode_audio(self, *args: Any, **kwargs: Any):
        ...


class TTSService(ModelService, Protocol):
    """Service contract for text-to-speech operations."""

    def synthesize(self, *args: Any, **kwargs: Any):
        ...


T = TypeVar("T")
logger = logging.getLogger(__name__)


def _offload_and_clear(model: object) -> None:
    """Best-effort release of GPU memory for a model-like object."""
    to_method = getattr(model, "to", None)
    if callable(to_method):
        # Most model wrappers in this codebase support .to(torch.device)
        to_method(torch.device("cpu"))
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


@dataclass
class FactoryModelService(Generic[T]):
    """Lazy service over existing model factory functions."""

    factory: Callable[[], T]
    label: str = "model"
    _instance: Optional[T] = None

    def start(self) -> None:
        if self._instance is None:
            self._instance = self.factory()
            logger.info("service.start label=%s", self.label)

    def stop(self) -> None:
        if self._instance is None:
            return
        _offload_and_clear(self._instance)
        self._instance = None
        logger.info("service.stop label=%s", self.label)

    def health(self) -> bool:
        return self._instance is not None

    def get(self) -> T:
        self.start()
        assert self._instance is not None
        return self._instance

    def move_to_device(self, device: str) -> None:
        model = self.get()
        to_method = getattr(model, "to", None)
        if callable(to_method):
            to_method(torch.device(device))
            logger.info("service.move label=%s device=%s", self.label, device)


class ASRModelService(FactoryModelService[Any]):
    """Typed adapter for ASR model services."""

    def transcribe(self, *args: Any, **kwargs: Any):
        return self.get().transcribe(*args, **kwargs)

    def transcribe_from_features(self, *args: Any, **kwargs: Any):
        return self.get().transcribe_from_features(*args, **kwargs)


class TextEmbeddingModelService(FactoryModelService[Any]):
    """Typed adapter for text embedding model services."""

    def encode(self, *args: Any, **kwargs: Any):
        return self.get().encode(*args, **kwargs)


class AudioEmbeddingModelService(FactoryModelService[Any]):
    """Typed adapter for audio embedding model services."""

    def encode_audio(self, *args: Any, **kwargs: Any):
        return self.get().encode_audio(*args, **kwargs)


class TTSModelService(FactoryModelService[Any]):
    """Typed adapter for TTS model services."""

    def synthesize(self, *args: Any, **kwargs: Any):
        return self.get().synthesize(*args, **kwargs)
