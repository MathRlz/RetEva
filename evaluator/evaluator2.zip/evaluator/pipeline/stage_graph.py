"""DAG-lite stage graph for current pipeline modes."""

from dataclasses import dataclass
from typing import Dict, List, Tuple


@dataclass(frozen=True)
class StageNode:
    """Single stage node in the execution DAG."""

    id: str
    stage: str
    depends_on: Tuple[str, ...] = ()


@dataclass(frozen=True)
class StageGraph:
    """Execution graph with deterministic topological levels."""

    mode: str
    nodes: Tuple[StageNode, ...]

    def node_ids(self) -> List[str]:
        return [node.id for node in self.nodes]

    def has_stage(self, stage: str) -> bool:
        return any(node.stage == stage for node in self.nodes)

    def topological_levels(self) -> List[List[StageNode]]:
        remaining: Dict[str, StageNode] = {node.id: node for node in self.nodes}
        resolved: set[str] = set()
        levels: List[List[StageNode]] = []

        while remaining:
            ready = sorted(
                [
                    node
                    for node in remaining.values()
                    if all(dep in resolved for dep in node.depends_on)
                ],
                key=lambda node: node.id,
            )
            if not ready:
                unresolved = ", ".join(sorted(remaining.keys()))
                raise ValueError(f"Cycle detected in stage graph: {unresolved}")

            levels.append(ready)
            for node in ready:
                resolved.add(node.id)
                remaining.pop(node.id, None)

        return levels


def build_stage_graph(mode: str, *, embedding_fusion_enabled: bool = False) -> StageGraph:
    """Build execution DAG for currently supported pipeline modes."""
    if mode == "asr_only":
        nodes = (
            StageNode(id="asr", stage="asr"),
            StageNode(id="metrics", stage="metrics", depends_on=("asr",)),
        )
    elif mode == "asr_text_retrieval":
        nodes = (
            StageNode(id="asr", stage="asr"),
            StageNode(id="text_embedding", stage="text_embedding", depends_on=("asr",)),
            StageNode(id="retrieval", stage="retrieval", depends_on=("text_embedding",)),
            StageNode(id="metrics", stage="metrics", depends_on=("retrieval",)),
        )
    elif mode == "audio_emb_retrieval":
        nodes = (
            StageNode(id="audio_embedding", stage="audio_embedding"),
            StageNode(id="retrieval", stage="retrieval", depends_on=("audio_embedding",)),
            StageNode(id="metrics", stage="metrics", depends_on=("retrieval",)),
        )
    elif mode == "audio_text_retrieval":
        if embedding_fusion_enabled:
            nodes = (
                StageNode(id="audio_embedding", stage="audio_embedding"),
                StageNode(id="text_embedding", stage="text_embedding"),
                StageNode(
                    id="fusion",
                    stage="fusion",
                    depends_on=("audio_embedding", "text_embedding"),
                ),
                StageNode(id="retrieval", stage="retrieval", depends_on=("fusion",)),
                StageNode(id="metrics", stage="metrics", depends_on=("retrieval",)),
            )
        else:
            nodes = (
                StageNode(id="audio_embedding", stage="audio_embedding"),
                StageNode(id="retrieval", stage="retrieval", depends_on=("audio_embedding",)),
                StageNode(id="metrics", stage="metrics", depends_on=("retrieval",)),
            )
    else:
        raise ValueError(f"Unknown pipeline mode: {mode}")

    return StageGraph(mode=mode, nodes=nodes)

