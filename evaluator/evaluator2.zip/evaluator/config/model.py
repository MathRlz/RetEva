"""Model configuration."""
from dataclasses import dataclass
from typing import Optional, Union

from ..config.types import PipelineMode, to_enum


@dataclass
class ModelConfig:
    """
    Configuration for model selection and device assignment.
    
    Specifies which models to use for each pipeline component (ASR, text embedding,
    audio embedding) and which devices they should run on. Supports optional
    PEFT/LoRA adapters for fine-tuned models.
    
    Attributes:
        asr_model_type: ASR model type identifier (e.g., "whisper", "wav2vec2"). Default: "wav2vec2".
        asr_model_name: Full model name/path. If None, uses registry default.
        asr_adapter_path: Path to PEFT/LoRA adapter for ASR model. Optional.
        asr_device: Device for ASR model. Default: "cuda:0".
        
        text_emb_model_type: Text embedding model type (e.g., "labse", "jina_v4"). Default: "labse".
        text_emb_model_name: Full model name/path. If None, uses registry default.
        text_emb_adapter_path: Path to PEFT/LoRA adapter for text embedding. Optional.
        text_emb_device: Device for text embedding model. Default: "cuda:1".
        
        audio_emb_model_type: Audio embedding model type (e.g., "attention_pool"). Optional.
        audio_emb_model_name: Full model name/path. If None, uses registry default.
        audio_emb_adapter_path: Path to PEFT/LoRA adapter for audio embedding. Optional.
        audio_emb_model_path: Path to pre-trained audio embedding model weights. Optional.
        audio_emb_dim: Embedding dimension for audio models. Default: 2048.
        audio_emb_dropout: Dropout rate for audio models. Default: 0.1.
        audio_emb_device: Device for audio embedding model. Default: "cuda:0".
        
        pipeline_mode: Pipeline configuration mode. Default: "asr_text_retrieval".
            Options: "asr_text_retrieval", "audio_emb_retrieval", "audio_text_retrieval", "asr_only".
    
    Examples:
        >>> config = ModelConfig(
        ...     asr_model_type="whisper",
        ...     asr_model_name="openai/whisper-small",
        ...     text_emb_model_type="jina_v4"
        ... )
        >>> config.auto_configure_devices()  # Auto-assign based on available GPUs
    """
    asr_model_type: Optional[str] = "wav2vec2"
    asr_model_name: Optional[str] = None
    asr_adapter_path: Optional[str] = None
    asr_device: str = "cuda:0"
    
    text_emb_model_type: Optional[str] = "labse"
    text_emb_model_name: Optional[str] = None
    text_emb_adapter_path: Optional[str] = None
    text_emb_device: str = "cuda:1"
    
    audio_emb_model_type: Optional[str] = None
    audio_emb_model_name: Optional[str] = None
    audio_emb_adapter_path: Optional[str] = None
    audio_emb_model_path: Optional[str] = None  # For pre-trained APM models
    audio_emb_dim: int = 2048  # Embedding dimension for attention pool models
    audio_emb_dropout: float = 0.1  # Dropout for attention pool models
    audio_emb_device: str = "cuda:0"
    
    pipeline_mode: Union[str, PipelineMode] = "asr_text_retrieval"
    
    def __post_init__(self):
        """Normalize pipeline_mode to enum."""
        if isinstance(self.pipeline_mode, str):
            self.pipeline_mode = to_enum(self.pipeline_mode, PipelineMode)
    
    def auto_configure_devices(self) -> None:
        """Auto-configure device assignments based on hardware availability.
        
        Sets asr_device, text_emb_device, and audio_emb_device to available devices.
        Avoids assigning cuda:1 if only 1 GPU is available.
        """
        import evaluator.config as config_module
        gpu_count = config_module.get_available_gpu_count()
        
        if gpu_count == 0:
            # No GPUs available, use CPU for all
            self.asr_device = "cpu"
            self.text_emb_device = "cpu"
            self.audio_emb_device = "cpu"
        elif gpu_count == 1:
            # Only one GPU, put everything on cuda:0
            self.asr_device = "cuda:0"
            self.text_emb_device = "cuda:0"
            self.audio_emb_device = "cuda:0"
        else:
            # Multiple GPUs: distribute models (ASR on 0, text emb on 1, audio on 0)
            self.asr_device = "cuda:0"
            self.text_emb_device = "cuda:1"
            self.audio_emb_device = "cuda:0"
