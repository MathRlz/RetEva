"""JINA v4 text embedding model implementation."""
from typing import List
import torch
import numpy as np
from transformers import AutoModel, AutoConfig
from ..base import TextEmbeddingModel
from ..registry import register_text_embedding_model


@register_text_embedding_model('jina_v4', default_name='jinaai/jina-embeddings-v4', description='JINA Embeddings v4')
class JinaV4Model(TextEmbeddingModel):
    """JINA Embeddings v4 text embedding model."""
    
    def __init__(self, model_name: str = "jinaai/jina-embeddings-v4"):
        jina_config = AutoConfig.from_pretrained(
            model_name, trust_remote_code=True
        )
        jina_config.verbosity = 0  # disable "encoding texts" message
        self.model = AutoModel.from_pretrained(
            model_name,
            config=jina_config,
            trust_remote_code=True,
            dtype=torch.bfloat16,
        )
        self.model_name = model_name

    def to(self, device: torch.device):
        self.model.to(device)
        return self

    def encode(self, texts: List[str], show_progress: bool = False) -> np.ndarray:
        task = "retrieval"
        prompt_name = "query"
        return_numpy = False
        torch_emb = self.model.encode_text(
            texts=texts, task=task, prompt_name=prompt_name, return_numpy=return_numpy
        )
        torch.cuda.empty_cache()
        return torch.stack(torch_emb).cpu().numpy()

    def name(self) -> str:
        return "JinaEmbeddingsV4"
