"""Factory functions for creating model instances."""
from typing import Optional
import torch
from .registry import asr_registry, text_embedding_registry, audio_embedding_registry, reranker_registry


def create_asr_model(model_type: str, model_name: Optional[str] = None, 
                     adapter_path: Optional[str] = None, device: str = "cuda:0"):
    """
    Factory function to create ASR models.
    
    Args:
        model_type: Type of ASR model (e.g., 'whisper', 'wav2vec2')
        model_name: Optional model name/path (uses registry default if None)
        adapter_path: Optional path to adapter weights
        device: Device to load model on
        
    Returns:
        ASRModel instance
    """
    # Ensure all models are imported and registered
    from .asr import whisper, wav2vec2, faster_whisper
    
    model_class = asr_registry.get(model_type)
    name = model_name or asr_registry.get_default_name(model_type)
    
    if name is None:
        available = asr_registry.list_types()
        raise ValueError(
            f"No default name for ASR model type '{model_type}'. Please provide model_name.\n"
            f"Registered ASR models: {', '.join(available)}"
        )
    
    return model_class(name, adapter_path=adapter_path).to(torch.device(device))


def create_text_embedding_model(model_type: str, model_name: Optional[str] = None, 
                                device: str = "cuda:0"):
    """
    Factory function to create text embedding models.
    
    Args:
        model_type: Type of text embedding model (e.g., 'labse', 'jina_v4', 'clip')
        model_name: Optional model name/path (uses registry default if None)
        device: Device to load model on
        
    Returns:
        TextEmbeddingModel instance or None for special cases
    """
    # Ensure all models are imported and registered
    from .t2e import labse, jina, clip, nemotron, bgem3
    
    # Special case for CLAP text embedding (handled by pipeline factory)
    if model_type == "clap_text":
        return None
    
    model_class = text_embedding_registry.get(model_type)
    name = model_name or text_embedding_registry.get_default_name(model_type)
    
    if name is None:
        available = text_embedding_registry.list_types()
        raise ValueError(
            f"No default name for text embedding model type '{model_type}'. Please provide model_name.\n"
            f"Registered text embedding models: {', '.join(available)}"
        )
    
    return model_class(name).to(torch.device(device))


def create_audio_embedding_model(model_type: str, model_name: Optional[str] = None,
                                 model_path: Optional[str] = None, 
                                 emb_dim: int = 2048, dropout: float = 0.1,
                                 device: str = "cuda:0"):
    """
    Factory function to create audio embedding models.
    
    Args:
        model_type: Type of audio embedding model (e.g., 'attention_pool', 'clap_style')
        model_name: Optional audio encoder name/path (uses registry default if None)
        model_path: Path to pre-trained model weights
        emb_dim: Embedding dimension
        dropout: Dropout rate
        device: Device to load model on
        
    Returns:
        AudioEmbeddingModel instance
    """
    # Ensure all models are imported and registered
    from .a2e import attention_pool, clap_style
    
    model_class = audio_embedding_registry.get(model_type)
    
    # Different models have different initialization parameters
    if model_type == "attention_pool":
        name = model_name or audio_embedding_registry.get_default_name(model_type)
        if name is None:
            available = audio_embedding_registry.list_types()
            raise ValueError(
                f"No default name for audio embedding model type '{model_type}'. Please provide model_name.\n"
                f"Registered audio embedding models: {', '.join(available)}"
            )
        return model_class(
            audio_encoder_name=name,
            emb_dim=emb_dim,
            model_path=model_path,
            dropout=dropout
        ).to(torch.device(device))
    elif model_type == "clap_style":
        if model_path is None:
            raise ValueError(
                "clap_style model requires 'model_path' to be specified.\n"
                "Provide the path to pre-trained CLAP model weights."
            )
        return model_class(
            model_path=model_path,
            device=device
        )
    else:
        available = audio_embedding_registry.list_types()
        raise NotImplementedError(
            f"Audio embedding model '{model_type}' initialization not configured.\n"
            f"Registered audio embedding models: {', '.join(available)}\n"
            f"Add initialization logic to factory.py for this model type."
        )


def create_reranker(
    model_type: str = "cross_encoder",
    model_name: Optional[str] = None,
    device: Optional[str] = None,
    batch_size: int = 32,
    max_length: int = 512,
):
    """
    Factory function to create reranker models.
    
    Args:
        model_type: Type of reranker model (e.g., 'cross_encoder')
        model_name: Optional model name/path (uses registry default if None)
        device: Device to load model on (auto-detect if None)
        batch_size: Batch size for scoring
        max_length: Maximum sequence length for tokenization
        
    Returns:
        BaseReranker instance
    """
    # Ensure reranker is registered
    _register_rerankers()
    
    model_class = reranker_registry.get(model_type)
    name = model_name or reranker_registry.get_default_name(model_type)
    
    if name is None:
        available = reranker_registry.list_types()
        raise ValueError(
            f"No default name for reranker type '{model_type}'. Please provide model_name.\n"
            f"Registered rerankers: {', '.join(available)}"
        )
    
    return model_class(
        model_name=name,
        device=device,
        batch_size=batch_size,
        max_length=max_length,
    )


def _register_rerankers():
    """Register all reranker models in the registry."""
    from .retrieval.rag.reranker import CrossEncoderReranker
    
    if not reranker_registry.is_registered("cross_encoder"):
        reranker_registry.register(
            "cross_encoder",
            CrossEncoderReranker,
            default_name="cross-encoder/ms-marco-MiniLM-L-6-v2",
            description="Cross-encoder reranker using sentence-transformers",
        )
