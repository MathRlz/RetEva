"""FastAPI application exposing evaluator runtime as HTTP backend."""

from __future__ import annotations

from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timezone
from threading import Lock
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional
from uuid import uuid4

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from evaluator import EvaluationConfig, list_presets, run_evaluation, run_evaluation_matrix
from evaluator.config.types import PipelineMode, VectorDBType
from evaluator.datasets import resolve_dataset_profile
from evaluator.pipeline import build_stage_graph
from evaluator.services import ModelServiceProvider
from evaluator.storage import ExperimentStore


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class EvaluationJobRequest(BaseModel):
    """Payload for single evaluation job creation."""

    config: Dict[str, Any] = Field(default_factory=dict)
    auto_devices: bool = True


class MatrixJobRequest(BaseModel):
    """Payload for matrix evaluation job creation."""

    base_config: Dict[str, Any] = Field(default_factory=dict)
    test_setups: List[Dict[str, Any]] = Field(default_factory=list)
    auto_devices: bool = True


class ConfigCreateRequest(BaseModel):
    """Payload for config creator endpoint."""

    preset_name: Optional[str] = None
    config_patch: Dict[str, Any] = Field(default_factory=dict)
    auto_devices: bool = True


@dataclass
class JobRecord:
    """In-memory job state for async API runs."""

    job_id: str
    job_type: str
    status: str = "queued"
    submitted_at: str = field(default_factory=_utc_now)
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    error: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    config_snapshot: Optional[Dict[str, Any]] = None
    cancel_requested: bool = False
    future: Optional[Future] = None

    def to_dict(self) -> Dict[str, Any]:
        """Return JSON-safe public representation."""
        return {
            "job_id": self.job_id,
            "job_type": self.job_type,
            "status": self.status,
            "submitted_at": self.submitted_at,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "cancel_requested": self.cancel_requested,
            "error": self.error,
            "has_result": self.result is not None,
            "has_config": self.config_snapshot is not None,
        }


class JobManager:
    """Minimal async job manager for backend API."""

    def __init__(
        self,
        *,
        evaluation_runner: Callable[[EvaluationConfig], Any],
        matrix_runner: Callable[[EvaluationConfig, List[Dict[str, Any]]], Dict[str, Any]],
        max_workers: int = 2,
    ) -> None:
        self._evaluation_runner = evaluation_runner
        self._matrix_runner = matrix_runner
        self._executor = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="evaluator-webapi")
        self._jobs: Dict[str, JobRecord] = {}
        self._lock = Lock()

    def submit_evaluation(self, config: EvaluationConfig) -> JobRecord:
        return self._submit(
            "evaluation",
            lambda: self._evaluation_runner(config).to_dict(include_config=True),
            config_snapshot=config.to_dict(),
        )

    def submit_matrix(self, config: EvaluationConfig, test_setups: List[Dict[str, Any]]) -> JobRecord:
        return self._submit(
            "matrix",
            lambda: self._matrix_runner(config, test_setups),
            config_snapshot=config.to_dict(),
        )

    def _submit(
        self,
        job_type: str,
        runner: Callable[[], Dict[str, Any]],
        *,
        config_snapshot: Optional[Dict[str, Any]] = None,
    ) -> JobRecord:
        job_id = str(uuid4())
        job = JobRecord(job_id=job_id, job_type=job_type, config_snapshot=config_snapshot)
        with self._lock:
            self._jobs[job_id] = job
        job.future = self._executor.submit(self._run_job, job_id, runner)
        return job

    def _run_job(self, job_id: str, runner: Callable[[], Dict[str, Any]]) -> None:
        with self._lock:
            job = self._jobs[job_id]
            if job.cancel_requested:
                job.status = "cancelled"
                job.finished_at = _utc_now()
                return
            job.status = "running"
            job.started_at = _utc_now()

        try:
            result = runner()
        except Exception as exc:  # surfaced to API clients
            with self._lock:
                job = self._jobs[job_id]
                job.status = "failed"
                job.error = str(exc)
                job.finished_at = _utc_now()
            return

        with self._lock:
            job = self._jobs[job_id]
            if job.cancel_requested:
                job.status = "cancelled"
                job.finished_at = _utc_now()
                return
            job.result = result
            job.status = "completed"
            job.finished_at = _utc_now()

    def get(self, job_id: str) -> JobRecord:
        with self._lock:
            if job_id not in self._jobs:
                raise KeyError(job_id)
            return self._jobs[job_id]

    def list_jobs(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [job.to_dict() for job in self._jobs.values()]

    def request_cancel(self, job_id: str) -> bool:
        with self._lock:
            if job_id not in self._jobs:
                raise KeyError(job_id)
            job = self._jobs[job_id]
            job.cancel_requested = True
            if job.status == "queued" and job.future and job.future.cancel():
                job.status = "cancelled"
                job.finished_at = _utc_now()
                return True
            return job.status in {"cancelled", "completed", "failed"}


def _deep_merge_dict(base: Dict[str, Any], patch: Dict[str, Any]) -> Dict[str, Any]:
    """Deep merge patch dict into base dict."""
    for key, value in patch.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            _deep_merge_dict(base[key], value)
        else:
            base[key] = value
    return base


def _nested_config(config: EvaluationConfig) -> Dict[str, Any]:
    """Return nested config shape for WebUI config creator."""
    return {
        "experiment_name": config.experiment_name,
        "output_dir": config.output_dir,
        "runtime": config.to_runtime_dict(),
        "experiment": config.to_experiment_dict(),
    }


def _create_config_options(provider_factory: Callable[[], ModelServiceProvider]) -> Dict[str, Any]:
    """Build form options for config creator UI."""
    provider = provider_factory()
    try:
        models = provider.list_available_models()
    finally:
        provider.shutdown()

    defaults = EvaluationConfig()
    return {
        "presets": list_presets(),
        "pipeline_modes": [mode.value for mode in PipelineMode],
        "vector_db_types": [db.value for db in VectorDBType],
        "retrieval_modes": ["dense", "sparse", "hybrid"],
        "hybrid_fusion_methods": ["weighted", "rrf", "max_score"],
        "reranker_modes": ["none", "token_overlap", "cross_encoder"],
        "service_runtime": {
            "startup_mode": ["lazy", "eager"],
            "offload_policy": ["on_finish", "never"],
        },
        "tts_providers": sorted({entry["type"] for entry in models.get("tts", [])}),
        "models": models,
        "defaults": _nested_config(defaults),
    }


def _graph_preview(config: EvaluationConfig) -> Dict[str, Any]:
    profile = resolve_dataset_profile(config.data.dataset_name, config.data.dataset_type)
    graph = build_stage_graph(
        str(config.model.pipeline_mode),
        embedding_fusion_enabled=bool(config.embedding_fusion.enabled),
    )
    return {
        "mode": graph.mode,
        "nodes": [
            {"id": node.id, "stage": node.stage, "depends_on": list(node.depends_on)}
            for node in graph.nodes
        ],
        "levels": [[node.id for node in level] for level in graph.topological_levels()],
        "dataset_profile": {
            "name": profile.name,
            "dataset_type": str(profile.dataset_type),
            "requires_audio": profile.requires_audio,
            "requires_text": profile.requires_text,
            "supports_generation": profile.supports_generation,
            "evaluation_mode": profile.evaluation_mode,
            "recommended_pipeline_modes": list(profile.recommended_pipeline_modes),
            "pipeline_mode_supported": profile.supports_pipeline_mode(str(config.model.pipeline_mode)),
        },
    }


def _artifact_listing(output_dir: Optional[str], *, max_entries: int = 200) -> List[Dict[str, Any]]:
    if not output_dir:
        return []
    base = Path(output_dir)
    if not base.exists() or not base.is_dir():
        return []

    files: List[Dict[str, Any]] = []
    for path in sorted(base.rglob("*")):
        if not path.is_file():
            continue
        rel_path = str(path.relative_to(base))
        stat = path.stat()
        files.append(
            {
                "path": rel_path,
                "size_bytes": stat.st_size,
                "modified_at": datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat(),
            }
        )
        if len(files) >= max_entries:
            break
    return files


def create_app(
    *,
    evaluation_runner: Callable[[EvaluationConfig], Any] = run_evaluation,
    matrix_runner: Callable[[EvaluationConfig, List[Dict[str, Any]]], Dict[str, Any]] = run_evaluation_matrix,
    provider_factory: Callable[[], ModelServiceProvider] = ModelServiceProvider,
) -> FastAPI:
    """Create FastAPI app for evaluator WebUI backend."""
    app = FastAPI(title="Evaluator Web API", version="1.0.0")
    jobs = JobManager(
        evaluation_runner=evaluation_runner,
        matrix_runner=matrix_runner,
    )

    @app.get("/api/health")
    def health() -> Dict[str, str]:
        return {"status": "ok"}

    @app.get("/api/presets")
    def presets() -> Dict[str, List[str]]:
        return {"presets": list_presets()}

    @app.get("/api/models")
    def list_models() -> Dict[str, Any]:
        provider = provider_factory()
        try:
            return provider.list_available_models()
        finally:
            provider.shutdown()

    @app.get("/api/services/status")
    def service_status() -> Dict[str, Any]:
        provider = provider_factory()
        try:
            models = provider.list_available_models()
        finally:
            provider.shutdown()
        return {
            "status": "ok",
            "available_models": models,
            "checked_at": _utc_now(),
        }

    @app.get("/api/config/options")
    def config_options() -> Dict[str, Any]:
        return _create_config_options(provider_factory)

    @app.post("/api/config/validate")
    def validate_config(payload: EvaluationJobRequest) -> Dict[str, Any]:
        config = EvaluationConfig.from_dict(payload.config)
        if payload.auto_devices:
            config = config.with_auto_devices()
        return {"config": config.to_dict()}

    @app.post("/api/graph/preview")
    def graph_preview(payload: EvaluationJobRequest) -> Dict[str, Any]:
        config = EvaluationConfig.from_dict(payload.config)
        if payload.auto_devices:
            config = config.with_auto_devices()
        return _graph_preview(config)

    @app.post("/api/config/create")
    def create_config(payload: ConfigCreateRequest) -> Dict[str, Any]:
        if payload.preset_name:
            base_config = EvaluationConfig.from_preset(payload.preset_name, validate=False)
        else:
            base_config = EvaluationConfig()

        merged = _deep_merge_dict(_nested_config(base_config), dict(payload.config_patch))
        config = EvaluationConfig.from_dict(merged)
        if payload.auto_devices:
            config = config.with_auto_devices()
        return {
            "config": _nested_config(config),
            "flat": config.to_dict(),
        }

    @app.post("/api/jobs/evaluation")
    def submit_evaluation(payload: EvaluationJobRequest) -> Dict[str, str]:
        config = EvaluationConfig.from_dict(payload.config)
        if payload.auto_devices:
            config = config.with_auto_devices()
        job = jobs.submit_evaluation(config)
        return {"job_id": job.job_id}

    @app.post("/api/jobs/matrix")
    def submit_matrix(payload: MatrixJobRequest) -> Dict[str, str]:
        config = EvaluationConfig.from_dict(payload.base_config)
        if payload.auto_devices:
            config = config.with_auto_devices()
        job = jobs.submit_matrix(config, payload.test_setups)
        return {"job_id": job.job_id}

    @app.get("/api/jobs")
    def list_jobs() -> Dict[str, Any]:
        return {"jobs": jobs.list_jobs()}

    @app.get("/api/jobs/{job_id}")
    def job_status(job_id: str) -> Dict[str, Any]:
        try:
            job = jobs.get(job_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Job not found") from exc
        return job.to_dict()

    @app.post("/api/jobs/{job_id}/cancel")
    def cancel_job(job_id: str) -> Dict[str, Any]:
        try:
            accepted = jobs.request_cancel(job_id)
            status = jobs.get(job_id).status
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Job not found") from exc
        return {"job_id": job_id, "accepted": accepted, "status": status}

    @app.get("/api/jobs/{job_id}/result")
    def job_result(job_id: str) -> Dict[str, Any]:
        try:
            job = jobs.get(job_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Job not found") from exc
        if job.status in {"queued", "running"}:
            raise HTTPException(status_code=409, detail="Job still running")
        if job.status == "failed":
            raise HTTPException(status_code=500, detail=job.error or "Job failed")
        if job.status == "cancelled":
            raise HTTPException(status_code=409, detail="Job cancelled")
        return {"job_id": job_id, "result": job.result}

    @app.get("/api/jobs/{job_id}/metadata")
    def job_metadata(job_id: str) -> Dict[str, Any]:
        try:
            job = jobs.get(job_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Job not found") from exc

        result_metadata = {}
        if isinstance(job.result, dict):
            result_metadata = job.result.get("metadata", {}) if isinstance(job.result.get("metadata"), dict) else {}
        return {
            "job": job.to_dict(),
            "config": job.config_snapshot,
            "metadata": result_metadata,
        }

    @app.get("/api/jobs/{job_id}/artifacts")
    def job_artifacts(job_id: str) -> Dict[str, Any]:
        try:
            job = jobs.get(job_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Job not found") from exc

        output_dir: Optional[str] = None
        if job.config_snapshot is not None:
            output_dir = job.config_snapshot.get("output_dir")
        artifacts = _artifact_listing(output_dir)
        return {"job_id": job_id, "output_dir": output_dir, "artifacts": artifacts}

    @app.get("/api/leaderboard")
    def leaderboard(
        metric: str = "MRR",
        limit: int = 20,
        dataset_name: Optional[str] = None,
        pipeline_mode: Optional[str] = None,
        output_dir: str = "evaluation_results",
    ) -> Dict[str, Any]:
        store = ExperimentStore(db_path=str(Path(output_dir) / "leaderboard.sqlite"))
        rows = store.query_leaderboard(
            metric_name=metric,
            limit=limit,
            dataset_name=dataset_name,
            pipeline_mode=pipeline_mode,
        )
        return {
            "metric": metric,
            "rows": [
                {
                    "run_id": row.run_id,
                    "experiment_name": row.experiment_name,
                    "dataset_name": row.dataset_name,
                    "pipeline_mode": row.pipeline_mode,
                    "metric_value": row.metric_value,
                    "duration_seconds": row.duration_seconds,
                    "created_at": row.created_at,
                }
                for row in rows
            ],
        }

    return app
