"""HTTP API entrypoint for evaluator runtime."""

from .app import create_app

__all__ = ["create_app"]
